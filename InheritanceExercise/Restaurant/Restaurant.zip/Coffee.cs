﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    internal class Coffee : HotBeverage
    {
        private const double Coffmilliliters = 50;
        private const decimal Coffprice = 3.50M;
        public Coffee(string name, double caffeine) : base(name, Coffprice, Coffmilliliters)
        {
            Caffeine = caffeine;
        }

        //public override decimal Price { get => price; }
        // public override double Milliliters => milliliters;
        // public virtual double Caffeine { get; set; }
        public double Caffeine { get; set; }

    }
}
